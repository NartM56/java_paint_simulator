package ca.utoronto.utm.assignment2.paint;

public interface Shape {
    Shape cloner();
    void setThickness(double thickness);
}
